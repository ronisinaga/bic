@extends('jayakari.bic.general::layouts.default')
@section('content')
    <!-- BEGIN SLIDER -->
    <div class="page-slider margin-bottom-40">
        <div id="carousel-example-generic" class="carousel slide carousel-slider">
            <!-- Indicators -->
            <ol class="carousel-indicators carousel-indicators-frontend">
                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                <li data-target="#carousel-example-generic" data-slide-to="3"></li>
                <li data-target="#carousel-example-generic" data-slide-to="4"></li>
                <li data-target="#carousel-example-generic" data-slide-to="5"></li>
                <li data-target="#carousel-example-generic" data-slide-to="6"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <!-- First slide -->
                <div class="item carousel-item-eight active">
                    <div class="container">
                        <div class="carousel-position-six text-uppercase text-center">
                            <h2 class="margin-bottom-20 animate-delay carousel-title-v5" data-animation="animated fadeInDown">
                                Jayadi Kusuma atmaja <br/>
                            </h2>
                            <p class="carousel-subtitle-v6 text-uppercase" data-animation="animated fadeInDown">Judul penemuannya apa</p>
                            <p class="carousel-subtitle-v5 border-top-bottom margin-bottom-30" data-animation="animated fadeInDown">
                                Ringkasan yang menjelaskan apa sebenarnya temuannya dan manfaatnya seperti apa
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Second slide -->
                <div class="item carousel-item-nine">
                    <div class="container">
                        <!--<div class="carousel-position-six">
                            <h2 class="animate-delay carousel-title-v6 text-uppercase" data-animation="animated fadeInDown">
                                Need a website design?
                            </h2>
                            <p class="carousel-subtitle-v6 text-uppercase" data-animation="animated fadeInDown">
                                This is what you were looking for
                            </p>
                            <p class="carousel-subtitle-v7 margin-bottom-30" data-animation="animated fadeInDown">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.<br/>
                                Sed est nunc, sagittis at consectetur id.
                            </p>
                            <a class="carousel-btn-green" href="#" data-animation="animated fadeInUp">Purchase Now!</a>
                        </div>-->
                        <div class="carousel-position-six text-uppercase text-center">
                            <h2 class="margin-bottom-20 animate-delay carousel-title-v5" data-animation="animated fadeInDown">
                                Jayadi Kusuma atmaja <br/>
                            </h2>
                            <p class="carousel-subtitle-v6 text-uppercase" data-animation="animated fadeInDown">Judul penemuannya apa</p>
                            <p class="carousel-subtitle-v5 border-top-bottom margin-bottom-30" data-animation="animated fadeInDown">
                                Ringkasan yang menjelaskan apa sebenarnya temuannya dan manfaatnya seperti apa
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Third slide -->
                <div class="item carousel-item-ten">
                    <div class="container">
                        <div class="carousel-position-six text-uppercase text-center">
                            <h2 class="margin-bottom-20 animate-delay carousel-title-v5" data-animation="animated fadeInDown">
                                Jayadi Kusuma atmaja <br/>
                            </h2>
                            <p class="carousel-subtitle-v6 text-uppercase" data-animation="animated fadeInDown">Judul penemuannya apa</p>
                            <p class="carousel-subtitle-v5 border-top-bottom margin-bottom-30" data-animation="animated fadeInDown">
                                Ringkasan yang menjelaskan apa sebenarnya temuannya dan manfaatnya seperti apa
                            </p>
                        </div>
                    </div>
                </div>

                <div class="item carousel-item-eleven">
                    <div class="container">
                        <div class="carousel-position-six text-uppercase text-center">
                            <h2 class="margin-bottom-20 animate-delay carousel-title-v5" data-animation="animated fadeInDown">
                                Jayadi Kusuma atmaja <br/>
                            </h2>
                            <p class="carousel-subtitle-v6 text-uppercase" data-animation="animated fadeInDown">Judul penemuannya apa</p>
                            <p class="carousel-subtitle-v5 border-top-bottom margin-bottom-30" data-animation="animated fadeInDown">
                                Ringkasan yang menjelaskan apa sebenarnya temuannya dan manfaatnya seperti apa
                            </p>
                        </div>
                    </div>
                </div>

                <div class="item carousel-item-twelve">
                    <div class="container">
                        <div class="carousel-position-six text-uppercase text-center">
                            <h2 class="margin-bottom-20 animate-delay carousel-title-v5" data-animation="animated fadeInDown">
                                Jayadi Kusuma atmaja <br/>
                            </h2>
                            <p class="carousel-subtitle-v6 text-uppercase" data-animation="animated fadeInDown">Judul penemuannya apa</p>
                            <p class="carousel-subtitle-v5 border-top-bottom margin-bottom-30" data-animation="animated fadeInDown">
                                Ringkasan yang menjelaskan apa sebenarnya temuannya dan manfaatnya seperti apa
                            </p>
                        </div>
                    </div>
                </div>

                <div class="item carousel-item-thirteen">
                    <div class="container">
                        <div class="carousel-position-six text-uppercase text-center">
                            <h2 class="margin-bottom-20 animate-delay carousel-title-v5" data-animation="animated fadeInDown">
                                Jayadi Kusuma atmaja <br/>
                            </h2>
                            <p class="carousel-subtitle-v6 text-uppercase" data-animation="animated fadeInDown">Judul penemuannya apa</p>
                            <p class="carousel-subtitle-v5 border-top-bottom margin-bottom-30" data-animation="animated fadeInDown">
                                Ringkasan yang menjelaskan apa sebenarnya temuannya dan manfaatnya seperti apa
                            </p>
                        </div>
                    </div>
                </div>

                <div class="item carousel-item-fourteen">
                    <div class="container">
                        <div class="carousel-position-six text-uppercase text-center">
                            <h2 class="margin-bottom-20 animate-delay carousel-title-v5" data-animation="animated fadeInDown">
                                Jayadi Kusuma atmaja <br/>
                            </h2>
                            <p class="carousel-subtitle-v6 text-uppercase" data-animation="animated fadeInDown">Judul penemuannya apa</p>
                            <p class="carousel-subtitle-v5 border-top-bottom margin-bottom-30" data-animation="animated fadeInDown">
                                Ringkasan yang menjelaskan apa sebenarnya temuannya dan manfaatnya seperti apa
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Controls -->
            <a class="left carousel-control carousel-control-shop carousel-control-frontend" href="#carousel-example-generic" role="button" data-slide="prev">
                <i class="fa fa-angle-left" aria-hidden="true"></i>
            </a>
            <a class="right carousel-control carousel-control-shop carousel-control-frontend" href="#carousel-example-generic" role="button" data-slide="next">
                <i class="fa fa-angle-right" aria-hidden="true"></i>
            </a>
        </div>
    </div>
    <!-- END SLIDER -->

    <div class="main">
            <!-- BEGIN SERVICE BOX -->
        <div class="container">
        <div class="row service-box margin-bottom-40">
            <div class="col-md-2 col-sm-2">
                <div class="service-box-heading">
                    <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/icons/1-pangan-b.png"/>
                </div>
            </div>
            <div class="col-md-2 col-sm-2">
                <div class="service-box-heading">
                    <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/icons/2-energi-b.png"/>
                </div>
            </div>
            <div class="col-md-2 col-sm-2">
                <div class="service-box-heading">
                    <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/icons/3-transport-b.png"/>
                </div>
            </div>
            <div class="col-md-2 col-sm-2">
                <div class="service-box-heading">
                    <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/icons/4-tik-b.png"/>
                </div>
            </div>
            <div class="col-md-2 col-sm-2">
                <div class="service-box-heading">
                    <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/icons/5-hankam-b.png"/>
                </div>
            </div>
            <div class="col-md-2 col-sm-2">
                <div class="service-box-heading">
                    <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/icons/6-kesehatan-b.png"/>
                </div>
            </div>

            <div class="col-md-2 col-sm-2">
                <div class="service-box-heading">
                    <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/icons/7-material-b.png"/>
                </div>
            </div>
            <div class="col-md-2 col-sm-2">
                <div class="service-box-heading">
                    <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/icons/8-lainnya-b.png"/>
                </div>
            </div>
        </div>
        </div>
            <!-- END SERVICE BOX -->
        <div class="container">
            <!-- BEGIN BLOCKQUOTE BLOCK -->
            <div class="row quote-v1 margin-bottom-30">
                <div class="col-md-12">
                    <span>BIC - Bussiness Innovation Center</span>
                </div>
            </div>
            <!-- END BLOCKQUOTE BLOCK -->

            <!-- BEGIN RECENT WORKS -->
            <div class="row recent-work margin-bottom-40">
                <div class="col-md-3">
                    <h2><a href="portfolio.html">Innovasi Terkini</a></h2>
                    <p>Inovasi-inovasi anak bangsa terbaru yang telah disubmit ke bisnis inovation center.</p>
                </div>
                <div class="col-md-9">
                    <div class="owl-carousel owl-carousel3">
                        <div class="recent-work-item">
                            <em>
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal1.png" alt="Amazing Project" class="img-responsive">
                                <a href="<?php echo env('APP_URL'); ?>/general/inovasi/inovasidetail/Innovasi Pertama"><i class="fa fa-link"></i></a>
                                <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal1.png" class="fancybox-button" title="Project Name #1" data-rel="fancybox-button"><i class="fa fa-search"></i></a>
                            </em>
                            <a class="recent-work-description" href="javascript:;">
                                <strong>Innovasi Pertama</strong>
                                <b>Nama Inovator</b>
                            </a>
                        </div>
                        <div class="recent-work-item">
                            <em>
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal2.jpg" alt="Amazing Project" class="img-responsive">
                                <a href="<?php echo env('APP_URL'); ?>/general/inovasi/inovasidetail/Innovasi Kedua"><i class="fa fa-link"></i></a>
                                <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal2.jpg" class="fancybox-button" title="Project Name #1" data-rel="fancybox-button"><i class="fa fa-search"></i></a>
                            </em>
                            <a class="recent-work-description" href="javascript:;">
                                <strong>Innovasi Kedua</strong>
                                <b>Nama Inovator</b>
                            </a>
                        </div>
                        <div class="recent-work-item">
                            <em>
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal3.jpg" alt="Amazing Project" class="img-responsive">
                                <a href="<?php echo env('APP_URL'); ?>/general/inovasi/inovasidetail/Innovasi Ketiga"><i class="fa fa-link"></i></a>
                                <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal3.jpg" class="fancybox-button" title="Project Name #1" data-rel="fancybox-button"><i class="fa fa-search"></i></a>
                            </em>
                            <a class="recent-work-description" href="javascript:;">
                                <strong>Innovasi Ketiga</strong>
                                <b>Nama Inovator</b>
                            </a>
                        </div>
                        <div class="recent-work-item">
                            <em>
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal1.png" alt="Amazing Project" class="img-responsive">
                                <a href="<?php echo env('APP_URL'); ?>/general/inovasi/inovasidetail/Innovasi Keempat"><i class="fa fa-link"></i></a>
                                <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal1.png" class="fancybox-button" title="Project Name #1" data-rel="fancybox-button"><i class="fa fa-search"></i></a>
                            </em>
                            <a class="recent-work-description" href="javascript:;">
                                <strong>Innovasi Pertama</strong>
                                <b>Nama Inovator</b>
                            </a>
                        </div>
                        <div class="recent-work-item">
                            <em>
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal2.jpg" alt="Amazing Project" class="img-responsive">
                                <a href="<?php echo env('APP_URL'); ?>/general/inovasi/inovasidetail/Innovasi Kedua"><i class="fa fa-link"></i></a>
                                <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal2.jpg" class="fancybox-button" title="Project Name #1" data-rel="fancybox-button"><i class="fa fa-search"></i></a>
                            </em>
                            <a class="recent-work-description" href="javascript:;">
                                <strong>Innovasi Kedua</strong>
                                <b>Nama Inovator</b>
                            </a>
                        </div>
                        <div class="recent-work-item">
                            <em>
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal3.jpg" alt="Amazing Project" class="img-responsive">
                                <a href="<?php echo env('APP_URL'); ?>/general/inovasi/inovasidetail/Innovasi Ketiga"><i class="fa fa-link"></i></a>
                                <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal3.jpg" class="fancybox-button" title="Project Name #1" data-rel="fancybox-button"><i class="fa fa-search"></i></a>
                            </em>
                            <a class="recent-work-description" href="javascript:;">
                                <strong>Innovasi Ketiga</strong>
                                <b>Nama Inovator</b>
                            </a>
                        </div>
                        <div class="recent-work-item">
                            <em>
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal1.png" alt="Amazing Project" class="img-responsive">
                                <a href="<?php echo env('APP_URL'); ?>/general/inovasi/inovasidetail/Innovasi Ketiga"><i class="fa fa-link"></i></a>
                                <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal1.png" class="fancybox-button" title="Project Name #1" data-rel="fancybox-button"><i class="fa fa-search"></i></a>
                            </em>
                            <a class="recent-work-description" href="javascript:;">
                                <strong>Innovasi Pertama</strong>
                                <b>Nama Inovator</b>
                            </a>
                        </div>
                        <div class="recent-work-item">
                            <em>
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal2.jpg" alt="Amazing Project" class="img-responsive">
                                <a href="<?php echo env('APP_URL'); ?>/general/inovasi/inovasidetail/Innovasi Ketiga"><i class="fa fa-link"></i></a>
                                <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal2.jpg" class="fancybox-button" title="Project Name #1" data-rel="fancybox-button"><i class="fa fa-search"></i></a>
                            </em>
                            <a class="recent-work-description" href="javascript:;">
                                <strong>Innovasi Kedua</strong>
                                <b>Nama Inovator</b>
                            </a>
                        </div>
                        <div class="recent-work-item">
                            <em>
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal3.jpg" alt="Amazing Project" class="img-responsive">
                                <a href="<?php echo env('APP_URL'); ?>/general/inovasi/inovasidetail/Innovasi Ketiga"><i class="fa fa-link"></i></a>
                                <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/works/proposal3.jpg" class="fancybox-button" title="Project Name #1" data-rel="fancybox-button"><i class="fa fa-search"></i></a>
                            </em>
                            <a class="recent-work-description" href="javascript:;">
                                <strong>Innovasi Ketiga</strong>
                                <b>Nama Inovator</b>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END RECENT WORKS -->

            <!-- BEGIN TABS AND TESTIMONIALS -->
            <div class="row mix-block margin-bottom-40">
                <!-- TABS -->
                <div class="col-md-7 tab-style-1">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#tab-1" data-toggle="tab">Berita Terbaru</a></li>
                        <li><a href="#tab-2" data-toggle="tab">Berita Populer</a></li>
                        <li><a href="#tab-3" data-toggle="tab">Agenda Kerja</a></li>
                        <li><a href="#tab-4" data-toggle="tab">Inovasi Unggulan</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="tab-1">
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/GIZ 6_140_100.jpg" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/GIZ 6_140_100.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Penutupan Entrepreneurship Bootcamps.</b></h4>
                                    <p class="margin-bottom-10">Hari terakhir pelaksanaan Bootcamps diisi dengan serangkaian presentasi bisnis (pitching) dari seluruh peserta yang hadir. Masing-masing peserta menyampaikan ide startup-nya selama 10 menit sebelum dilanjutkan dengan 5 menit tanya jawab oleh fasilitator. Di sesi terakhir, program Bootcamps ditutup dengan pembagian sertifikat kepada masing-masing peserta diikuti dengan foto bersama...</p>
                                    <p><a class="more" href="<?php echo env('APP_URL'); ?>/general/berita/utama/Penutupan Entrepreneurship Bootcamps">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/GIZ-4_140_100.jpg" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/GIZ-4_140_100.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Entrepreneurship Bootcamps Hari ke 4 : Dua Jawara Entrepreneurship Indonesia Hadir untuk Berbagi.</b></h4>
                                    <p class="margin-bottom-10">Di hari keempat pelaksanaan program Entrepreneurship Bootcamps oleh GIZ (Sabtu, 25 November 2017), peserta mendapatkan kesempatan untuk mendengar dan menimba ilmu dari narasumber tamu yang sudah berpengalaman di dunia bisnis dan start-up. Mereka adalah Dr. Agung Bayu Waluyo (Ciputra Entrepreneurship Center) dan Muhammad Maulana (Uno Capital) yang berbagi ilmu dan pengalaman tentang membangun start-up selama kurang lebih 3 jam.</p>
                                    <p><a class="more" href="<?php echo env('APP_URL'); ?>/general/berita/utama/Penutupan Entrepreneurship Bootcamps">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/GIZ-1_140_100.jpg" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/GIZ-1_140_100.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Entrepreneurship Bootcamp : Business Idea for Development 2.0</b></h4>
                                    <p class="margin-bottom-10">GIZ adalah lembaga kerjasama internasional untuk pembangunan berkelanjutan, yang telah aktif di Indonesia sejak tahun 1975 dibawah naungan German Federal Ministry for Economic Cooperation and Development(BMZ)...</p>
                                    <p><a class="more" href="<?php echo env('APP_URL'); ?>/general/berita/utama/Penutupan Entrepreneurship Bootcamps">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/images1.jpeg" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/images1.jpeg" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Workshop : “How to Accelerate Public Private Partnership in Research” FK UI</b></h4>
                                    <p class="margin-bottom-10">Dalam rangka meningkatkan kualitas dan kuantitas hasil riset di bidang kedokteran, dan membangun jejaring kerjasama ABGC (Academic, Business, Government, Community), Indonesia Innovation for Health (INNOVATE) yang merupakan unit Technology Transfer Office (TTO) yang berada di bawah naungan Fakultas Kedokteran Universitas Indonesia, menyelenggarakan Workshop bertajuk “How to Accelerate Public Private Partnership in Research”. Pihak-pihak yang mewakili ABGC, diundang untuk berbagi pengalaman dari sudut pandang masing-masing, yang berkaitan dengan pengembangan dan kolaborasi penelitian di bidang kedokteran...</p>
                                    <p><a class="more" href="<?php echo env('APP_URL'); ?>/general/berita/utama/Penutupan Entrepreneurship Bootcamps">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/IFIC_Resize_140_100.jpg" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/IFIC_Resize_140_100.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Kegiatan kunjungan kedaerah.</b></h4>
                                    <p class="margin-bottom-10">Kegiatan kunjungan daerah dilakukan dalam upaya untuk memperkenalkan dan menyebarluaskan BIC (Business Innovation Center) sebagai wadah untuk menjembatani antara inovator dan pengusaha dalam menciptakan produk unggulan</p>
                                    <p><a class="more" href="<?php echo env('APP_URL'); ?>/general/berita/utama/Penutupan Entrepreneurship Bootcamps">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab-2">
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/GIZ 6_140_100.jpg" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/GIZ 6_140_100.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Penutupan Entrepreneurship Bootcamps.</b></h4>
                                    <p class="margin-bottom-10">Hari terakhir pelaksanaan Bootcamps diisi dengan serangkaian presentasi bisnis (pitching) dari seluruh peserta yang hadir. Masing-masing peserta menyampaikan ide startup-nya selama 10 menit sebelum dilanjutkan dengan 5 menit tanya jawab oleh fasilitator. Di sesi terakhir, program Bootcamps ditutup dengan pembagian sertifikat kepada masing-masing peserta diikuti dengan foto bersama...</p>
                                    <p><a class="more" href="<?php echo env('APP_URL'); ?>/general/berita/utama/Penutupan Entrepreneurship Bootcamps">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/GIZ-4_140_100.jpg" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/GIZ-4_140_100.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Entrepreneurship Bootcamps Hari ke 4 : Dua Jawara Entrepreneurship Indonesia Hadir untuk Berbagi.</b></h4>
                                    <p class="margin-bottom-10">Di hari keempat pelaksanaan program Entrepreneurship Bootcamps oleh GIZ (Sabtu, 25 November 2017), peserta mendapatkan kesempatan untuk mendengar dan menimba ilmu dari narasumber tamu yang sudah berpengalaman di dunia bisnis dan start-up. Mereka adalah Dr. Agung Bayu Waluyo (Ciputra Entrepreneurship Center) dan Muhammad Maulana (Uno Capital) yang berbagi ilmu dan pengalaman tentang membangun start-up selama kurang lebih 3 jam.</p>
                                    <p><a class="more" href="<?php echo env('APP_URL'); ?>/general/berita/utama/Penutupan Entrepreneurship Bootcamps">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/GIZ-1_140_100.jpg" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/GIZ-1_140_100.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Entrepreneurship Bootcamp : Business Idea for Development 2.0</b></h4>
                                    <p class="margin-bottom-10">GIZ adalah lembaga kerjasama internasional untuk pembangunan berkelanjutan, yang telah aktif di Indonesia sejak tahun 1975 dibawah naungan German Federal Ministry for Economic Cooperation and Development(BMZ)...</p>
                                    <p><a class="more" href="<?php echo env('APP_URL'); ?>/general/berita/utama/Penutupan Entrepreneurship Bootcamps">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/images1.jpeg" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/images1.jpeg" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Workshop : “How to Accelerate Public Private Partnership in Research” FK UI</b></h4>
                                    <p class="margin-bottom-10">Dalam rangka meningkatkan kualitas dan kuantitas hasil riset di bidang kedokteran, dan membangun jejaring kerjasama ABGC (Academic, Business, Government, Community), Indonesia Innovation for Health (INNOVATE) yang merupakan unit Technology Transfer Office (TTO) yang berada di bawah naungan Fakultas Kedokteran Universitas Indonesia, menyelenggarakan Workshop bertajuk “How to Accelerate Public Private Partnership in Research”. Pihak-pihak yang mewakili ABGC, diundang untuk berbagi pengalaman dari sudut pandang masing-masing, yang berkaitan dengan pengembangan dan kolaborasi penelitian di bidang kedokteran...</p>
                                    <p><a class="more" href="<?php echo env('APP_URL'); ?>/general/berita/utama/Penutupan Entrepreneurship Bootcamps">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/IFIC_Resize_140_100.jpg" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/IFIC_Resize_140_100.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Kegiatan kunjungan kedaerah.</b></h4>
                                    <p class="margin-bottom-10">Kegiatan kunjungan daerah dilakukan dalam upaya untuk memperkenalkan dan menyebarluaskan BIC (Business Innovation Center) sebagai wadah untuk menjembatani antara inovator dan pengusaha dalam menciptakan produk unggulan</p>
                                    <p><a class="more" href="<?php echo env('APP_URL'); ?>/general/berita/utama/Penutupan Entrepreneurship Bootcamps">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab-3">
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/agenda_.png" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/agenda_.png" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Agenda Kerja 1</b></h4>
                                    <p class="margin-bottom-10">Tanggal: 15 November 2017</p>
                                    <p><a class="more" href="home/kegiatan">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div><br>
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/agenda_.png" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/agenda_.png" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Agenda Kerja 2</b></h4>
                                    <p class="margin-bottom-10">Tanggal: 20 November 2017</p>
                                    <p><a class="more" href="home/kegiatan">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div><br>
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/agenda_.png" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/agenda_.png" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Agenda Kerja 3</b></h4>
                                    <p class="margin-bottom-10">Tanggal: 20 November 2017</p>
                                    <p><a class="more" href="home/kegiatan">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab-4">
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/gliserol.png" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/gliserol.png" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Pabrik Gliserol Tak Kasat Mata</b></h4>
                                    <p class="margin-bottom-10">
                                        Gliserol adalah salah satu komponen yang terkandung dalam limbah industri biodiesel. Semakin meningkat produksi biodiesel, maka limbah gliserol yang dihasilkan juga semakin meningkat. Meskipun gliserol murni banyak digunakan dalam industri makanan, farmasi, kosmetik, dan industri-industri lainnya, pemurnian limbah gliserol menjadi gliserol murni umumnya sangat mahal dan tidak efektif.....</p>
                                    <p><a class="more" href="inovasi/inovasidetail/Innovasi Pertama">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/api_biru.png" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/api_biru.png" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Api biru.</b></h4>
                                    <p class="margin-bottom-10">Pembuatan bioethanol membutuhkan limbah pasar segar seperti sayuran dan buah segar yang dibuang dan dikumpulkan menjadi satu. Sampah kemudian dihancurkan dengan mesin giling sehingga dihasilkan cairan sampah organik yang kemudian difermentasikan selama 7 hari...</p>
                                    <p><a class="more" href="inovasi/inovasidetail/Innovasi Pertama">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/jagung.png" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/jagung.png" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Ini Jagung, Bukan Terigu!</b></h4>
                                    <p class="margin-bottom-10">Teknologi ini menjawab tatangan selama ini penggunaan terigu yang belum bisa 100% tergantikan dalam industri mie. Mie kering yang terbuat dari tepung jagung 100% ini memiliki karakteristik dan sifat (ketegangan, elongasi, kelembaban, kelengketan, dan cooking loss) yang menyerupai mie terigu setelah proses produksinya.
                                        Mi jagung ini cocok untuk penderita autis karena tidak mengandung gluten dan juga penderita diabetes karena sudah terjadi perubahan sifat pati akibat pemanasan saat pencetakan mie...</p>
                                    <p><a class="more" href="<?php echo env('APP_URL'); ?>/general/inovasi/inovasidetail/Innovasi Pertama">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/penyuara.jpg" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/penyuara.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Penyuara Tersamar Berbentuk Bebas</b></h4>
                                    <p class="margin-bottom-10">Penyuara berkualitas, umumnya kotak persegi dan kaku bentuknya. Hal ini bisa mengurangi nilai estetika sebuah ruangan atau peralatan yang menghasilkan suara itu sendiri. Kalaupun disamarkan umumnya ditutupi dengan bahan berlubang yang berwarna serupa dengan alat atau daerah sekitarnya...</p>
                                    <p><a class="more" href="inovasi/inovasidetail/Innovasi Pertama">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <a href="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/cangkang.jpg" class="fancybox-button" title="Image Title" data-rel="fancybox-button">
                                        <img class="img-responsive" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/photos/cangkang.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-md-9 col-sm-9">
                                    <h4 class="margin-bottom-10"><b>Cangkang Sahabat Tulang</b></h4>
                                    <p class="margin-bottom-10">Prosedur grafting tulang adalah prosedur bedah rekonstruksi untuk menempatkan bahan pengganti tulang menggantikan tulang yang rusak atau patah (fraktur). Selama ini bahan pengganti yang digunakan adalah logam, yang dapat memperlemah tulang sehingga tulang mudah mengalami fraktur kembali...</p>
                                    <p><a class="more" href="inovasi/inovasidetail/Innovasi Pertama">Read more <i class="icon-angle-right"></i></a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END TABS -->

                <!-- TESTIMONIALS -->
                <div class="col-md-5 testimonials-v1">
                    <div id="myCarousel" class="carousel slide">
                        <!-- Carousel items -->
                        <div class="carousel-inner">
                            <div class="active item">
                                <blockquote><p>Banyak faktor yang menyebabkan Iptek nasional belum memberikan kontribusi besar terhadap pertumbuhan ekonomi. Bukan hanya bila dilakukan perbandingan terhadap negara maju bahkan new emerging industralizing countries (AS dan Kelompok Negara Barat serta Korea Selatan, Cina, India, Brazil, bahkan Malaysia, tetangga kita). Mereka telah memposisikan iptek menjadi lokomotif pertumbuhan ekonomi. Sektor Iptek nasional belum bisa terhitung sebagai topik yang wajib dibahas dalam berbagai diskusi tentang perkembangan ekonomi negara tercinta...</p>
                                <p><a class="more" href="javascript:;">Read more <i class="icon-angle-right"></i></a></p></blockquote>
                                <div class="carousel-info">
                                    <img class="pull-left" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/people/kusmayanto-kadiman.png" alt="">
                                    <div class="pull-left">
                                        <span class="testimonials-name">Kusmayanto Kadiman</span>
                                        <span class="testimonials-post">Menristek (2004-2009)</span>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <blockquote><p>Hari ini dua tahun yang lalu, saya pertama kalinya datang ke BIC, dan agak terkejut dengan desain bangunannya yang modern dan futuristik. Lokasi BIC di dalam kompleks Mega Kemayoran juga sangat menguntungkan karena fasilitas parkirnya yang luas dan nyaman. Ada kolam dengan ikan koi di depan kantor, taman kecil yang asri, membuat suasana depan kantor BIC sangat nyaman....</p>
                                <p><a class="more" href="javascript:;">Read more <i class="icon-angle-right"></i></a></p></blockquote>
                                <div class="carousel-info">
                                    <img class="pull-left" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/people/Hariyanto-Salim.jpg" alt="">
                                    <div class="pull-left">
                                        <span class="testimonials-name">Hariyanto Salim</span>
                                        <span class="testimonials-post">Direktur YYY</span>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <blockquote><p>Semuanya cuma berawal dari “wacana”?Ditambah sejumput semangat dan keyakinan. Walau semula tak tahu kami mau ke mana? Semangatpun kami angkat  jadi  “master-plan”...</p>
                                <p><a class="more" href="javascript:;">Read more <i class="icon-angle-right"></i></a></p></blockquote>
                                <div class="carousel-info">
                                    <img class="pull-left" src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/people/Kristanto-Santosa.jpg" alt="">
                                    <div class="pull-left">
                                        <span class="testimonials-name">Kristanto Santosa</span>
                                        <span class="testimonials-post">Bussines Innovation Center</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Carousel nav -->
                        <a class="left-btn" href="#myCarousel" data-slide="prev"></a>
                        <a class="right-btn" href="#myCarousel" data-slide="next"></a>
                    </div>
                </div>
                <!-- END TESTIMONIALS -->
            </div>
            <!-- END TABS AND TESTIMONIALS -->

            <!-- BEGIN STEPS -->
            <div class="row margin-bottom-40 front-steps-wrapper front-steps-count-3">
                <div class="col-md-4 col-sm-4 front-step-col">
                    <div class="front-step front-step1">
                        <h2>Visi</h2>
                        <p>Visi dari Business Innovation Center (BIC).</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 front-step-col">
                    <div class="front-step front-step2">
                        <h2>Misi</h2>
                        <p>Misi dari Business Innovation Center (BIC).</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 front-step-col">
                    <div class="front-step front-step3">
                        <h2>Motto</h2>
                        <p>Motto dari Business Innovation Center (BIC).</p>
                    </div>
                </div>
            </div>
            <!-- END STEPS -->

            <!-- BEGIN CLIENTS -->
            <div class="row margin-bottom-40 our-clients">
                <div class="col-md-3">
                    <h2><a href="javascript:;">Partner Kami</a></h2>
                    <p>Partner-partner yang selama ini mendukung kegiatan kami.</p>
                </div>
                <div class="col-md-9">
                    <div class="owl-carousel owl-carousel6-brands">
                        <div class="client-item">
                            <a href="javascript:;">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_1_gray.png" class="img-responsive" alt="">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_1.png" class="color-img img-responsive" alt="">
                            </a>
                        </div>
                        <div class="client-item">
                            <a href="javascript:;">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_2_gray.png" class="img-responsive" alt="">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_2.png" class="color-img img-responsive" alt="">
                            </a>
                        </div>
                        <div class="client-item">
                            <a href="javascript:;">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_3_gray.png" class="img-responsive" alt="">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_3.png" class="color-img img-responsive" alt="">
                            </a>
                        </div>
                        <div class="client-item">
                            <a href="javascript:;">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_4_gray.png" class="img-responsive" alt="">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_4.png" class="color-img img-responsive" alt="">
                            </a>
                        </div>
                        <div class="client-item">
                            <a href="javascript:;">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_5_gray.png" class="img-responsive" alt="">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_5.png" class="color-img img-responsive" alt="">
                            </a>
                        </div>
                        <div class="client-item">
                            <a href="javascript:;">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_6_gray.png" class="img-responsive" alt="">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_6.png" class="color-img img-responsive" alt="">
                            </a>
                        </div>
                        <div class="client-item">
                            <a href="javascript:;">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_7_gray.png" class="img-responsive" alt="">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_7.png" class="color-img img-responsive" alt="">
                            </a>
                        </div>
                        <div class="client-item">
                            <a href="javascript:;">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_8_gray.png" class="img-responsive" alt="">
                                <img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/pages/img/clients/client_8.png" class="color-img img-responsive" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END CLIENTS -->
        </div>
    </div>
@stop