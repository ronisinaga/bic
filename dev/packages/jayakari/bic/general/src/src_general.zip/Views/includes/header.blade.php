<!-- BEGIN TOP BAR -->
<div class="pre-header">
    <div class="container">
        <div class="row">
            <!-- BEGIN TOP BAR LEFT PART -->
            <div class="col-md-12 col-sm-12 additional-shop-info">
                <ul class="list-unstyled list-inline">
                    <li><img src="<?php echo env('APP_URL'); ?>/public/jayakari/bic/regular/corporates/img/logos/logo.png"></li>
                    <li><i class="fa fa-phone"></i><span>+6221 4288 5430</span></li>
                    <li><i class="fa fa-fax"></i><span>+62 21 2147 2655</span></li>
                    <li><i class="fa fa-phone"></i><span>+62 21 4288 5430</span></li>
                    <li><i class="fa fa-phone"></i><span>+62 8118 242 558 (BIC-JKT)</span></li>
                    <li><i class="fa fa-phone"></i><span>+62 8118 242 462 (BIC-INA)</span></li>
                    <li><i class="fa fa-envelope-o"></i><span>info@bic.web.id</span></li>
                </ul>
            </div>

        </div>
    </div>
</div>
<!-- END TOP BAR -->

<!-- BEGIN HEADER -->
<div class="header">

</div>
<!-- Header END -->

