@extends('jayakari.bic.general::layouts.default')
@section('content')
    <div class="main">
        <div class="container">
            <ul class="breadcrumb">
                <li><a href="index.html">Berita</a></li>
                <li><a href="javascript:;">Utama</a></li>
                <li class="active">Penutupan Entrepreneurship Bootcamps</li>
            </ul>
            <!-- BEGIN SIDEBAR & CONTENT -->
            <div class="row margin-bottom-40">
                <!-- BEGIN CONTENT -->
                <div class="col-md-12 col-sm-12">
                    <h1>Penutupan Entrepreneurship Bootcamps</h1>
                    <div class="content-page">
                        <div class="row">
                            <!-- BEGIN LEFT SIDEBAR -->
                            <div class="col-md-9 col-sm-9 blog-item">
                                <div class="blog-item-img">
                                    <!-- BEGIN CAROUSEL -->
                                    <div class="front-carousel">
                                        <div id="myCarousel" class="carousel slide">
                                            <!-- Carousel items -->
                                            <div class="carousel-inner">
                                                <div class="item active">
                                                    <img src="/bic_new/public/jayakari/bic/regular/pages/img/posts/GIZ 6.jpg" alt="">
                                                </div>
                                                <div class="item">
                                                    <img src="/bic_new/public/jayakari/bic/regular/pages/img/posts/GIZ 7.jpg" alt="">
                                                </div>
                                                <div class="item">
                                                    <img src="/bic_new/public/jayakari/bic/regular/pages/img/posts/GIZ 8.jpg" alt="">
                                                </div>
                                                <div class="item">
                                                    <img src="/bic_new/public/jayakari/bic/regular/pages/img/posts/GIZ 9.jpg" alt="">
                                                </div>
                                            </div>
                                            <!-- Carousel nav -->
                                            <a class="carousel-control left" href="#myCarousel" data-slide="prev">
                                                <i class="fa fa-angle-left"></i>
                                            </a>
                                            <a class="carousel-control right" href="#myCarousel" data-slide="next">
                                                <i class="fa fa-angle-right"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <!-- END CAROUSEL -->
                                </div>
                                <p>Hari terakhir pelaksanaan Bootcamps diisi dengan serangkaian presentasi bisnis (pitching) dari seluruh peserta yang hadir. Masing-masing peserta
                                    menyampaikan ide startup-nya selama 10 menit sebelum dilanjutkan dengan 5 menit tanya jawab oleh fasilitator. Di sesi terakhir, program Bootcamps
                                    ditutup dengan pembagian sertifikat kepada masing-masing peserta diikuti dengan foto bersama.</p>
                                <p>Hari terakhir pelaksanaan Bootcamps diisi dengan serangkaian presentasi bisnis (pitching) dari seluruh peserta yang hadir. Masing-masing peserta
                                    menyampaikan ide startup-nya selama 10 menit sebelum dilanjutkan dengan 5 menit tanya jawab oleh fasilitator. Di sesi terakhir, program Bootcamps
                                    ditutup dengan pembagian sertifikat kepada masing-masing peserta diikuti dengan foto bersama.</p>
                                <p>Hari terakhir pelaksanaan Bootcamps diisi dengan serangkaian presentasi bisnis (pitching) dari seluruh peserta yang hadir. Masing-masing peserta
                                    menyampaikan ide startup-nya selama 10 menit sebelum dilanjutkan dengan 5 menit tanya jawab oleh fasilitator. Di sesi terakhir, program Bootcamps
                                    ditutup dengan pembagian sertifikat kepada masing-masing peserta diikuti dengan foto bersama.</p>
                                <p>Hari terakhir pelaksanaan Bootcamps diisi dengan serangkaian presentasi bisnis (pitching) dari seluruh peserta yang hadir. Masing-masing peserta
                                    menyampaikan ide startup-nya selama 10 menit sebelum dilanjutkan dengan 5 menit tanya jawab oleh fasilitator. Di sesi terakhir, program Bootcamps
                                    ditutup dengan pembagian sertifikat kepada masing-masing peserta diikuti dengan foto bersama.</p>

                                <h2>Komentar</h2>
                                <div class="comments">
                                    <div class="media">
                                        <a href="javascript:;" class="pull-left">
                                            <img src="/bic_new/public/jayakari/bic/regular/pages/img/people/Hariyanto-Salim.jpg" alt="" class="media-object">
                                        </a>
                                        <div class="media-body">
                                            <h4 class="media-heading">Komentar 1 <span>5 hours ago</span></h4>
                                            <p>Ini adalah komentar pertama dari berita diatas. Ini adalah komentar pertama dari berita diatas. Ini adalah komentar pertama dari berita diatas. Ini adalah komentar pertama dari berita diatas. </p>
                                        </div>
                                    </div>
                                    <!--end media-->
                                    <div class="media">
                                        <a href="javascript:;" class="pull-left">
                                            <img src="/bic_new/public/jayakari/bic/regular/pages/img/people/alihaliman.jpg" alt="" class="media-object">
                                        </a>
                                        <div class="media-body">
                                            <h4 class="media-heading">Komentar 2 <span>July 25,2013</span></h4>
                                            <p>Ini Komentar kedua dari berita diatas. Ini Komentar kedua dari berita diatas. Ini Komentar kedua dari berita diatas. Ini Komentar kedua dari berita diatas. Ini Komentar kedua dari berita diatas. Ini Komentar kedua dari berita diatas. </p>
                                        </div>
                                    </div>
                                    <!--end media-->
                                </div>

                                <div class="post-comment padding-top-40">
                                    <h3>Tinggalkan Pesan</h3>
                                    <form role="form">
                                        <div class="form-group">
                                            <label>Nama</label>
                                            <input class="form-control" type="text">
                                        </div>

                                        <div class="form-group">
                                            <label>Email <span class="color-red">*</span></label>
                                            <input class="form-control" type="text">
                                        </div>

                                        <div class="form-group">
                                            <label>Pesan</label>
                                            <textarea class="form-control" rows="8"></textarea>
                                        </div>
                                        <p><button class="btn btn-primary" type="submit">Kirim Pesan</button></p>
                                    </form>
                                </div>
                            </div>
                            <!-- END LEFT SIDEBAR -->

                            <!-- BEGIN RIGHT SIDEBAR -->
                            <div class="col-md-3 col-sm-3 blog-sidebar">
                                <!-- CATEGORIES START -->
                                <h2 class="no-top-space">Kategori Berita</h2>
                                <ul class="nav sidebar-categories margin-bottom-40">
                                    <li><a href="javascript:;">Utama (18)</a></li>
                                    <li><a href="javascript:;">Inovasi (5)</a></li>
                                    <li><a href="javascript:;">Teknologi (7)</a></li>
                                    <li><a href="javascript:;">Serba Serbi (3)</a></li>
                                </ul>
                                <!-- CATEGORIES END -->

                                <!-- BEGIN RECENT NEWS -->
                                <h2>Berita Terbaru</h2>
                                <div class="recent-news margin-bottom-10">
                                    <div class="row margin-bottom-10">
                                        <div class="col-md-3">
                                            <img class="img-responsive" alt="" src="/bic_new/public/jayakari/bic/regular/pages/img/people/Hariyanto-Salim.jpg">
                                        </div>
                                        <div class="col-md-9 recent-news-inner">
                                            <h3><a href="javascript:;">Entrepreneurship Bootcamps Hari ke 4 : Dua Jawara Entrepreneurship Indonesia Hadir untuk Berbagi</a></h3>
                                            <p>Ini dia berita dari enterpreneurship bootcamps hari ke 4</p>
                                        </div>
                                    </div>
                                    <div class="row margin-bottom-10">
                                        <div class="col-md-3">
                                            <img class="img-responsive" alt="" src="/bic_new/public/jayakari/bic/regular/pages/img/people/Hariyanto-Salim.jpg">
                                        </div>
                                        <div class="col-md-9 recent-news-inner">
                                            <h3><a href="javascript:;">Entrepreneurship Bootcamp : Business Idea for Development 2.0</a></h3>
                                            <p>Ini dia berita dari enterpreneurship bootcamps</p>
                                        </div>
                                    </div>
                                    <div class="row margin-bottom-10">
                                        <div class="col-md-3">
                                            <img class="img-responsive" alt="" src="/bic_new/public/jayakari/bic/regular/pages/img/people/Hariyanto-Salim.jpg">
                                        </div>
                                        <div class="col-md-9 recent-news-inner">
                                            <h3><a href="javascript:;">Workshop : “How to Accelerate Public Private Partnership in Research” FK UI</a></h3>
                                            <p>Ini berita dari Workshop : “How to Accelerate Public Private Partnership in Research” FK UI</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- END RECENT NEWS -->
                            </div>
                            <!-- END RIGHT SIDEBAR -->
                        </div>
                    </div>
                </div>
                <!-- END CONTENT -->
            </div>
            <!-- END SIDEBAR & CONTENT -->
        </div>
    </div>
@stop