<?php
/**
 * Created by PhpStorm.
 * User: alienware
 * Date: 12/22/2017
 * Time: 9:58 AM
 */

namespace jayakari\bic\general\Controllers;

use App\Http\Controllers\Controller;


class BeritaController extends Controller
{
    public function showBerita($kategori,$title){
        return view('jayakari.bic.general::pages.berita.showBerita');
    }
}