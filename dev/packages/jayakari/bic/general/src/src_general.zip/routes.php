<?php
/**
 * Created by PhpStorm.
 * User: Roni Sinaga
 * Date: 11/23/2017
 * Time: 4:01 AM
 */

Route::get('/general/home/','jayakari\bic\general\Controllers\HomeController@index');
Route::get('/general/home/kegiatan','jayakari\bic\general\Controllers\HomeController@kegiatan');
Route::get('/general/about/','jayakari\bic\general\Controllers\AboutController@index');
Route::get('/general/inovasi/','jayakari\bic\general\Controllers\InnovasiController@index');
Route::get('/general/inovasi/inovasipertahun/{tahun}','jayakari\bic\general\Controllers\InnovasiController@inovasipertahun');
Route::get('/general/inovasi/inovasidetail/{judul}','jayakari\bic\general\Controllers\InnovasiController@inovasidetail');
Route::get('/general/berita/','jayakari\bic\general\Controllers\InnovasiController@index');
Route::get('/general/berita/{kategori}/{title}','jayakari\bic\general\Controllers\BeritaController@showBerita');
Route::get('/general/login/','jayakari\bic\general\Controllers\HomeController@login');
Route::get('/general/manual','jayakari\bic\general\Controllers\HomeController@manual');
Route::get('/general/manual/inovator','jayakari\bic\general\Controllers\HomeController@inovator');
Route::get('/general/manual/inovator/{id}','jayakari\bic\general\Controllers\HomeController@detailInovator');
Route::get('/general/manual/reviewer','jayakari\bic\general\Controllers\HomeController@reviewer');
Route::get('/general/manual/reviewer/{id}','jayakari\bic\general\Controllers\HomeController@detailReviewer');
Route::get('/general/manual/proses','jayakari\bic\general\Controllers\HomeController@adminProses');
Route::get('/general/manual/proses/{id}','jayakari\bic\general\Controllers\HomeController@detailAdminProses');
Route::get('/general/manual/juri','jayakari\bic\general\Controllers\HomeController@juri');
Route::get('/general/manual/juri/{id}','jayakari\bic\general\Controllers\HomeController@detailJuri');
Route::get('/general/diagram','jayakari\bic\general\Controllers\HomeController@diagram');
Route::post('/general/sendEmail','jayakari\bic\general\Controllers\HomeController@sendEmail');
Route::get('/general/registrasi/','jayakari\bic\general\Controllers\HomeController@registrasi');
Route::get('/general/terimakasih/','jayakari\bic\general\Controllers\HomeController@terimakasih');
Route::get('/general/email/','jayakari\bic\general\Controllers\HomeController@emailContent');
Route::get('/general/statistic','jayakari\bic\general\Controllers\HomeController@statistic');